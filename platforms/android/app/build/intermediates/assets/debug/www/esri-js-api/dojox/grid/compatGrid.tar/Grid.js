dojo.provide("dojox.grid.Grid");
dojo.require("dojox.grid.compat.Grid");
dojo.deprecated("dojox.grid.Grid");
